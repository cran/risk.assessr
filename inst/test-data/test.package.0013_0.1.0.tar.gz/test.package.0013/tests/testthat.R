library(testthat)
library(test.package.0013)

test_check("test.package.0013")
