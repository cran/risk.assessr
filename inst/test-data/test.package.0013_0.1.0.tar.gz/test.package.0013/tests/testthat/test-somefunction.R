test_that("somefunction adds one to a number", {
  expect_equal(somefunction(1), 2)
  expect_equal(somefunction(0), 1)
  expect_equal(somefunction(-1), 0)
})

test_that("somefunction handles non-numeric input gracefully", {
  expect_error(somefunction("a"), "Must be of type 'numeric'")
  expect_error(somefunction(NA), "Contains missing values")
  expect_error(somefunction(c(1, 2)), "Must have length 1")
})

