#' @export
somefunction <- function(x) {
  checkmate::assert_numeric(x, any.missing = FALSE, len = 1)
  x + 1
}
