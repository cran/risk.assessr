test_that("Value of .pt is correct", {
  expected_pt <- 72.27 / 25.4
  expect_equal(.pt, expected_pt)
})
